package com.example.workfitapplication.Logic.Enum;

public enum Type {
    Biceps,
    Triceps,
    Chest,
    Back,
    Legs,
    Abs,
    Cardio
}
